package Assistedproject;

public class TypeCastingExample {

	public static void main(String[] args) {
	
		        int intValue = 10;
		        long longValue = intValue;

		        float floatValue = 2.07f;
		        double doubleValue = floatValue;

		        System.out.println("Implicit Casting (Widening):");
		        System.out.println("int to long: " + longValue);
		        System.out.println("float to double: " + doubleValue);

		        
		        double bigDouble = 123.456;
		        int smallInt = (int) bigDouble;

		        long bigLong = 6369589047L;
		        int smallInt2 = (int) bigLong;

		        System.out.println("\nExplicit Casting (Narrowing):");
		        System.out.println("double to int: " + smallInt);
		        System.out.println("long to int: " + smallInt2);

		        
		        double lossyDouble = 456.789;
		        int lossyInt = (int) lossyDouble;

		        System.out.println("\nPotential Loss of Information:");
		        System.out.println("double to int (lossy): " + lossyInt);
		    }
		


	}


