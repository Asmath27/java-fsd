package Assistedproject;

public class Main2 {

	public static void main(String[] args) {
		
	        
	        AccessModifierExample example = new AccessModifierExample();
	        
	        
	        System.out.println("Public field: " + example.publicField);
	        System.out.println("Protected field: " + example.protectedField);
	        System.out.println("Default field: " + example.defaultField);
	        System.out.println("Private field: " + example.privateField);

	        
	        example.protectedMethod();
	        example.defaultMethod();
	        example.privateMethod();
	    }
	


	}


