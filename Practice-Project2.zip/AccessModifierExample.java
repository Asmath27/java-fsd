package Assistedproject;

public class AccessModifierExample {

	    public int publicField = 10;

	    
	    protected int protectedField = 20;

	    
	    int defaultField = 30;

	    
	    int privateField = 40;

	 
	    public AccessModifierExample() {
	        System.out.println("Public constructor called");
	    }

	    
	    protected void protectedMethod() {
	        System.out.println("Protected method called");
	    }

	   
	    void defaultMethod() {
	        System.out.println("Default method called");
	    }

	    
	    void privateMethod() {
	        System.out.println("Private method called");
	    }


}
