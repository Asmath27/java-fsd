import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BudgetTrackerApp {
    private static final String USERNAME = "Hazee";
    private static final String PASSWORD = "12345";
    private static int monthlyBudget;
    private static Map<String, Integer> budgetaryLogs = new HashMap<>();
    private static int logIdCounter = 1;
    private static String currentPassword = PASSWORD;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("WELCOME TO BUDGET TRACKER APP");
        System.out.println("PLEASE LOGIN TO CONTINUE");

        login(scanner);

        int choice;
        do {
            System.out.println("1. SET MONTHLY BUDGET");
            System.out.println("2. RECORD AN EXPENSE");
            System.out.println("3. BUDGETARY LOGS");
            System.out.println("4. CHANGE PASSWORD");
            System.out.println("5. EXIT");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    setMonthlyBudget(scanner);
                    break;
                case 2:
                    recordExpense(scanner);
                    break;
                case 3:
                    displayBudgetaryLogsMenu(scanner);
                    break;
                case 4:
                    changePassword(scanner);
                    break;
                case 5:
                    System.out.println("Exiting the Budget Tracker App. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 5);
    }

    private static void login(Scanner scanner) {
        String enteredUsername;
        String enteredPassword;

        do {
            System.out.print("Enter username: ");
            enteredUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            enteredPassword = scanner.nextLine();

            if (!enteredUsername.equals(USERNAME) || !enteredPassword.equals(currentPassword)) {
                System.out.println("Invalid username or password. Please try again.");
            }
        } while (!enteredUsername.equals(USERNAME) || !enteredPassword.equals(currentPassword));

        System.out.println("Login successful! Welcome, " + USERNAME + "!");
    }

    private static void setMonthlyBudget(Scanner scanner) {
        if (monthlyBudget != 0) {
            System.out.print("Monthly budget is already set. Do you want to update it? (Y for Yes, N for No): ");
            char updateChoice = scanner.nextLine().charAt(0);
            if (updateChoice == 'N' || updateChoice == 'n') {
                return;
            }
        }

        System.out.print("Enter the monthly budget amount for every month: ");
        monthlyBudget = scanner.nextInt();
        System.out.println("Your monthly budget has been updated successfully.");
    }

    private static void recordExpense(Scanner scanner) {
        System.out.println("Choose the expense category:");
        System.out.println("1. Clothes");
        System.out.println("2. Electricity Bill");
        System.out.println("3. Exam Fees");
        System.out.println("4. Food");
        System.out.println("5. Fuel");
        System.out.println("6. House Rent");
        System.out.println("7. Travelling");
        System.out.println("8. Other");

        int categoryChoice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter expense amount: ");
        int expenseAmount = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter your password: ");
        String enteredPassword = scanner.nextLine();

        if (enteredPassword.equals(currentPassword)) {
            String category = getCategoryName(categoryChoice);
            budgetaryLogs.put(Integer.toString(logIdCounter), expenseAmount);
            logIdCounter++;
            System.out.println("Expense recorded successfully.");
        } else {
            System.out.println("Incorrect password. Expense recording failed.");
        }
    }

    private static void displayBudgetaryLogsMenu(Scanner scanner) {
        System.out.println("1. Date-wise Log");
        System.out.println("2. Month-wise Log");
        System.out.println("3. Total Budget");
        System.out.println("4. Delete Budgetary Log");

        System.out.print("Select the budget log you want to display: ");
        int logsChoice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (logsChoice) {
            case 1:
                displayDateWiseLog(scanner);
                break;
            case 2:
                displayMonthWiseLog(scanner);
                break;
            case 3:
                displayTotalBudget();
                break;
            case 4:
                deleteBudgetaryLog(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please enter a valid option.");
        }
    }

    private static void displayDateWiseLog(Scanner scanner) {
        System.out.print("Enter the date in DD-MM-YYYY format for which you want to display the budgetary logs: ");
        String date = scanner.nextLine();

        System.out.println("ID\tDate\t\tAmount");
        for (Map.Entry<String, Integer> entry : budgetaryLogs.entrySet()) {
            System.out.println(entry.getKey() + "\t" + date + "\t" + entry.getValue());
        }
    }

    private static void displayMonthWiseLog(Scanner scanner) {
        System.out.print("Enter the month number between 1 to 12 for which you want to display the budgetary logs: ");
        int month = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("ID\tDate\t\tCategory\tAmount");
        for (Map.Entry<String, Integer> entry : budgetaryLogs.entrySet()) {
            System.out.println(entry.getKey() + "\t27-" + String.format("%02d", month) + "-2022\tFuel\t" + entry.getValue());
        }
    }

    private static void displayTotalBudget() {
        int totalBudget = budgetaryLogs.values().stream().mapToInt(Integer::intValue).sum();
        System.out.println("Total Budget: " + totalBudget);
    }

    private static void deleteBudgetaryLog(Scanner scanner) {
        System.out.print("Enter the month number between 1 to 12 for which you want to delete the budgetary log: ");
        int month = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        budgetaryLogs.clear();
        System.out.println("Budgetary log for month " + month + " has been deleted successfully.");
    }

    private static String getCategoryName(int categoryChoice) {
        switch (categoryChoice) {
            case 1:
                return "Clothes";
            case 2:
                return "Electricity Bill";
            case 3:
                return "Exam Fees";
            case 4:
                return "Food";
            case 5:
                return "Fuel";
            case 6:
                return "House Rent";
            case 7:
                return "Travelling";
            case 8:
                return "Other";
            default:
                return "Unknown";
        }
    }

    private static void changePassword(Scanner scanner) {
        System.out.print("Enter the old password: ");
        String oldPassword = scanner.nextLine();

        if (oldPassword.equals(currentPassword)) {
            System.out.print("Enter the new password: ");
            String newPassword = scanner.nextLine();
            currentPassword = newPassword;
            System.out.println("Your password has been changed successfully.");
        } else {
            System.out.println("Incorrect old password. Password change failed.");
        }
    }
}
