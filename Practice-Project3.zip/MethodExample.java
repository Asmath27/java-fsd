package Assistedproject;

public class MethodExample {
	
	    static void staticMethod() {
	        System.out.println("This is a static method.");
	    }

	    
	    void instanceMethod() {
	        System.out.println("This is an instance method.");
	    }

	    
	    void methodWithParameters(int a, int b) {
	        System.out.println("Sum of " + a + " and " + b + " is: " + (a + b));
	    }

	  
	    void methodOverloading() {
	        System.out.println("Method without parameters.");
	    }

	    void methodOverloading(int num) {
	        System.out.println("Method with parameter: " + num);
	    }

	    void methodOverloading(String str) {
	        System.out.println("Method with parameter: " + str);
	    }

	  
	    void overriddenMethod() {
	        System.out.println("This is the original method.");
	    }
	}

	class Subclass extends MethodExample {
	   
	   
	    void overriddenMethod() {
	        System.out.println("This is the overridden method in the subclass.");
	    }
	}



