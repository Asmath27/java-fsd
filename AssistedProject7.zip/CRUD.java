
import java.io.IOException;

import java.nio.file.Files;

import java.nio.file.Paths;

import java.util.List;

public class CRUD {

    public static void main(String[] args) {
        
        String filePath = "example.txt";

        createFile(filePath);

        
        readFromFile(filePath);

       
        updateFile(filePath, "Updated content");

        
        readFromFile(filePath);

        
        deleteFile(filePath);
    }

    
    private static void createFile(String filePath) {
        
    	try {
            
    		String content = "Hi,My name is Hazeena!";
    		
            Files.write(Paths.get(filePath), content.getBytes());
            
            System.out.println("File created.");
            
        } 
    	
    	catch (IOException e)
    	{
            e.printStackTrace();
        }
    }

   
    private static void readFromFile(String filePath) 
    {
        try 
        {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            
            System.out.println("File content:");
            
            for (String line : lines) {
                System.out.println(line);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private static void updateFile(String filePath, String newContent)
    {
        try 
        {
            Files.write(Paths.get(filePath), newContent.getBytes());
            System.out.println("File updated.");
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    private static void deleteFile(String filePath)
    {
        try 
        {
            Files.delete(Paths.get(filePath));
            System.out.println("File deleted.");
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
